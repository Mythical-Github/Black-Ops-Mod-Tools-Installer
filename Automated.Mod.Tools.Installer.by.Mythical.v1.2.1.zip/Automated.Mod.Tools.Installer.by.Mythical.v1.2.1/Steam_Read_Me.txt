BO1 Game + Mod Tools + Linker_Mod Installer by Mythical (Version 1.0):

	Notes:
Some errors/warning when the converter is ran is normal, you can ignore them.
This will take up 12-13gb.
It is reccomended to keep your game install separate from your modding install, but not neccesary.

	Requirements:
Windows, Steam Installed, Black Ops 1 Owned on Steam.
	
Step 1)
Steam_Install.bat in a text editor and replace "YOURUSERNAME" and "YOURPASSWORD" with yours.
Feel free to read the code while you're here, then save.

Step 2)
Create and name a folder, then place the Steam_Install.bat inside or place it inside your Black Ops 1 game install.
This will be where everything is installed to.

Step 3)
Run the Steam_Install.bat (this will take a while, less if you are using an existing game installation).
It will install everything in the proper order for you, when prompted allow black ops to be open.
(No need to close it, it will do that itself, just have it go fullscreen and load to the menu)

Step 3)
Once the batch is finished it will show credits nice ascii art, then will close itself.
You are ready to go!

	Summary:
Q: Why do I need to put my username and password in the bat, and do I have to do that to use this?
A: This is for steamcmd to know you own the game and let you install. No you don't!!! you can install the game & mod tools via steam and use the Non-Steam_Install.bat version.

Q: The install got interrupted what do I do?
A: Click inside the cmd window and hit enter, if that doesn't work close it, then run the Steam_Install.bat.

Q: What does this do exactly?:
A: Downloads then installs Steam CMD, Black Ops 1, Black Ops 1 Mod Tools, Game_Mod, Linker_Mod, & BO1 Radiant exe files.
Next it will run setup.bat, the converter, then will download & install the asset pack & mod tools fix.
Then it will delete the unneeded files to save space.

Q: Why did you make it?
A: People were having trouble with setting up the tools. This will get more people to a working install stage :D.

Q: Why didn't you use the preprovided download links for some packages?
A: Certain characters, and file formats that were in them wouldn't work in the batch file, so I renamed, changed formats, & uploaded.

Q: What if something else went wrong?
A: If you've read everything here, and googled what you can, and it's still not working feel free to @ me or ask for help in the Linkermod Discord's help channel https://discord.gg/RMt88x3Js4

	Credits:
SE2Dev (Linker_Mod/Game_Mod/wip Asset Package)
Nukem9 (Linker_Mod/Game_Mod)
Jbleezy (Linker_Mod/Game_Mod)
dtzxporter (Linker_Mod/Game_Mod)
Ville88 (Mod Tools Fix)
Treyarch & Activision (Game)
Valve (SteamCMD)
Marcin Glinski (Ascii Art)
Everyone who worked on Linker_Mod/Game_Mod
(If I missed anybody let me know)