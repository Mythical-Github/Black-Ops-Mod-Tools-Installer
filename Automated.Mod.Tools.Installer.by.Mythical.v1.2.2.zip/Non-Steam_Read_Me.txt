BO1 Linker_Mod Installer by Mythical (Version 1.2.2):

	Notes:

Some errors/warning when the converter is ran is normal, you can ignore them.
This will add approximately 281 MB to your game/mod tools install.
It is reccomended to keep your game install separate from your modding install, but not neccesary.

	Requirements:

Windows, Black Ops 1, Black Ops 1 Mod Tools Installed
	
Step 1) 
Open Non-Steam_Install.bat in a text editor and rename both instances of BlackOps.exe to the .exe of your game if need be.
(Example: Rekt T5M would be "t5m.exe")
Feel free to read the code while you're here, then save.

Step 2)
Place the Non-Steam_Install.bat into your the folder of your Black Ops 1 Installation. 

Step 3) 
Run the Non_Steam.Install.bat (this will a little while)
It will install everything in the proper order for you, when prompted allow black ops to be open 
(No need to close it, it will do that itself, just have it go fullscreen and load to the menu)

Step 4)
Once the batch is finished it will show credits nice ascii art, then will close itself.
You are ready to go!

	Summary:
Q: The install got interrupted what do I do?
A: Click inside the cmd window and hit enter, if that doesn't work close it, then run the Non-Steam_Install.bat.

Q: What does this do exactly?:
A: Downloads then installs Game_Mod, Linker_Mod, & BO1 Radiant exe files.
Next it will run setup.bat, the converter, then will download & install the asset pack & mod tools fix.
Then it will delete the unneeded files to save space.

Q: Why did you make it?
A: People were having trouble with setting up the tools. This will get more people to a working install stage :D.

Q: Why didn't you use the preprovided download links for some packages?
A: Certain characters, and file formats that were in them wouldn't work in the batch file, so I renamed, changed formats, & uploaded.

Q: What if something else went wrong?
A: If you've read everything here, and googled what you can, and it's still not working feel free to @ me or ask for help in the Linkermod Discord's help channel https://discord.gg/RMt88x3Js4

	Credits:
SE2Dev (Linker_Mod/Game_Mod/wip Asset Package)
Nukem9 (Linker_Mod/Game_Mod)
Jbleezy (Linker_Mod/Game_Mod)
dtzxporter (Linker_Mod/Game_Mod)
Ville88 (Mod Tools Fix)
Treyarch & Activision (Game)
Valve (SteamCMD)
Marcin Glinski (Ascii Art)
Everyone who worked on Linker_Mod/Game_Mod
(If I missed anybody let me know)